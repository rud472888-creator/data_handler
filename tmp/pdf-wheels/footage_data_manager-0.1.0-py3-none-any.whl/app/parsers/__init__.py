"""Parser contract package placeholder."""
