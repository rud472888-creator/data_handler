"""Runtime-owned job execution orchestration."""

from __future__ import annotations

import json
from pathlib import Path

from app.persistence.db import Database
from app.persistence.models import Job, SystemVolume
from app.persistence.repositories import EventRepository, JobRepository
from app.runtime.lifecycle import JobLifecycleService
from app.runtime.offload import DestinationPlan, OffloadService, ReplicaPath, SourcePath
from app.runtime.reports import ReportService
from app.runtime.state_machine import JobState
from app.runtime.volume_monitor import VolumeProvider


class JobRunnerError(RuntimeError):
    """Raised when a runtime job cannot be executed."""


class RuntimeJobRunner:
    """Connect queued API jobs to the runtime-only execution services."""

    def __init__(
        self,
        *,
        database: Database,
        lifecycle: JobLifecycleService,
        volume_provider: VolumeProvider,
    ) -> None:
        self.database = database
        self.lifecycle = lifecycle
        self.volume_provider = volume_provider

    def run(self, job_id: str) -> None:
        """Run one queued job through clone, checksum, and report generation."""

        try:
            if not self._transition(job_id, JobState.SCANNING):
                return
            job = self._require_job(job_id)
            source_paths, plan = self.resolve_job_paths(job)
            if not self._transition(job_id, JobState.PREPARING):
                return
            if not self._transition(job_id, JobState.COPYING):
                return
            offload = OffloadService(self.database).execute(
                job_id=job_id,
                source_paths=source_paths,
                plan=plan,
                finalize_state=False,
            )
            if offload.state is JobState.FAILED:
                self._transition(job_id, JobState.FAILED)
                return
            if not self._transition(job_id, JobState.VERIFYING):
                return
            project_root = plan.report_project_root
            if not self._transition(job_id, JobState.REPORTING):
                return
            ReportService(self.database).generate(
                job_id=job_id,
                project_root=project_root,
            )
            self._transition(
                job_id,
                JobState.WARN if offload.state is JobState.WARN else JobState.COMPLETED,
            )
        except Exception as exc:
            self._record_failure(job_id, exc)

    def resolve_job_paths(self, job: Job) -> tuple[tuple[SourcePath, ...], DestinationPlan]:
        volumes = {volume.volume_id: volume for volume in self._volumes()}
        sources = tuple(
            SourcePath(
                path_id=path_id,
                root=Path(self._require_volume(volumes, path_id, "source").display_path),
            )
            for path_id in job.source_path_ids
        )
        replicas = tuple(
            ReplicaPath(
                path_id=path_id,
                root=Path(self._require_volume(volumes, path_id, "destination").display_path),
            )
            for path_id in job.replica_path_ids
        )
        return (
            sources,
            DestinationPlan(
                project_name=job.project_name,
                replica_paths=replicas,
                footage_run_name=_policy_footage_run_name(job.policy_json),
                flat_card_layout=json.loads(job.policy_json).get("flat_card_layout") is True,
            ),
        )

    def project_root_for_job(self, job: Job) -> Path:
        _, plan = self.resolve_job_paths(job)
        return plan.report_project_root

    def _require_job(self, job_id: str) -> Job:
        with self.database.session() as connection:
            job = JobRepository(connection).get(job_id)
        if job is None:
            raise JobRunnerError(f"job not found: {job_id}")
        return job

    def _transition(self, job_id: str, state: JobState) -> bool:
        return self.lifecycle.transition_job(job_id, state).accepted

    def _volumes(self) -> list[SystemVolume]:
        snapshot = self.volume_provider.scan()
        return snapshot.sources + snapshot.destinations

    def _require_volume(
        self,
        volumes: dict[str, SystemVolume],
        volume_id: str,
        kind: str,
    ) -> SystemVolume:
        volume = volumes.get(volume_id)
        if volume is None or volume.kind != kind:
            raise JobRunnerError(f"{kind} volume not found: {volume_id}")
        return volume

    def _record_failure(self, job_id: str, exc: Exception) -> None:
        with self.database.session() as connection:
            jobs = JobRepository(connection)
            events = EventRepository(connection)
            job = jobs.get(job_id)
            state_before = job.state if job else None
            if job is not None and JobState(job.state) not in {
                JobState.FAILED,
                JobState.CANCELLED,
                JobState.COMPLETED,
            }:
                jobs.update_state(job_id, JobState.FAILED, current_step="failed")
            events.append(
                "runtime_job_failed",
                job_id=job_id,
                state_before=state_before,
                state_after=JobState.FAILED.value,
                accepted=False,
                reason=str(exc),
            )


def _policy_footage_run_name(policy_json: str) -> str | None:
    try:
        policy = json.loads(policy_json or "{}")
    except json.JSONDecodeError:
        return None
    value = policy.get("footage_run_name")
    if not value:
        return None
    run_name = str(value)
    path = Path(run_name)
    if path.is_absolute() or "\\" in run_name or "\x00" in run_name:
        return None
    if any(part in {"", ".", ".."} for part in path.parts):
        return None
    return run_name
