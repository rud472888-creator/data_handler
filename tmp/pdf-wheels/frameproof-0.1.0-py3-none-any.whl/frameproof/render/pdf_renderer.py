"""Flowing, Korean-capable sampled-frame reports from the supplied report models.

Presentation never probes media or changes capture/manifest semantics. Canvas is
used only for bounded running furniture; all report content uses Platypus.
"""
from __future__ import annotations

from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from io import BytesIO
import json
from pathlib import Path
import re
from xml.sax.saxutils import escape

from PIL import Image, ImageOps
from reportlab.lib import colors  # type: ignore[import-untyped]
from reportlab.lib.pagesizes import A4, landscape, letter  # type: ignore[import-untyped]
from reportlab.lib.styles import ParagraphStyle  # type: ignore[import-untyped]
from reportlab.pdfbase import pdfmetrics  # type: ignore[import-untyped]
from reportlab.pdfbase.ttfonts import TTFont  # type: ignore[import-untyped]
from reportlab.pdfgen.canvas import Canvas  # type: ignore[import-untyped]
from reportlab.platypus import (  # type: ignore[import-untyped]
    BaseDocTemplate, CondPageBreak, Frame, HRFlowable, Image as PDFImage,
    LongTable, PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle,
)

from frameproof.config.settings import AppSettings, PathDisplayMode, ReportLayout
from frameproof.core.models import BatchSummary, CapturePoint, CaptureStatus, ClipInfo, ClipStatus, ReportItem

CONTACT_SHEET_PAGE_SIZE = A4
DETAIL_PAGE_SIZE = landscape(letter)
MARGIN = 42.0
PDF_IMAGE_MAX_PIXELS = 1600
PDF_IMAGE_QUALITY = 86
FONT_REGULAR = "DataHandlerSans"
FONT_BOLD = "DataHandlerSans-Bold"
FONT_DIRECTORY = Path(__file__).with_name("fonts")
INK = colors.HexColor("#20282B")
MUTED = colors.HexColor("#5C696C")
TEAL = colors.HexColor("#0B5B61")
RULE = colors.HexColor("#D4DEDF")


@dataclass(frozen=True)
class CapturePresentation:
    label: str
    cells: tuple[str, ...]


@dataclass(frozen=True)
class ClipPresentation:
    number: int
    item: ReportItem
    identity: tuple[tuple[str, str], ...]
    media: tuple[tuple[str, str], ...]
    captures: tuple[CapturePresentation, ...]
    raw: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class ReportPresentation:
    title: str
    clips: tuple[ClipPresentation, ...]
    warning_clips: int
    error_clips: int
    capture_counts: tuple[tuple[str, int], ...]


def _value(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "예 / true" if value else "아니요 / false"
    if isinstance(value, Enum):
        return str(value.value)
    return str(value)


def _integer(value: int | None) -> str:
    return f"{value:,}" if value is not None else "-"


def _seconds_display(value: float | None) -> str:
    return f"{value:.3f} s" if value is not None else "-"


def _fps_display(clip: ClipInfo) -> str:
    if clip.fps_num is None or clip.fps_den is None:
        return "-"
    return f"{clip.fps_num}/{clip.fps_den} ({clip.fps_num / clip.fps_den:.3f} fps)"


def _display_path(source_path: str, mode: PathDisplayMode) -> str:
    path = Path(source_path)
    if mode is PathDisplayMode.FULL:
        return str(path)
    if mode is PathDisplayMode.BASENAME:
        return path.name
    return f"hidden ({path.name})"


def _path_key(key: str) -> bool:
    normalized = re.sub(r"(?<!^)(?=[A-Z])", "_", key).lower().replace("-", "_")
    return bool({"path", "paths"}.intersection(normalized.split("_"))) or normalized in {"file", "files", "filename", "file_name", "part_files"} or normalized.endswith(("_file", "_files", "_filename"))


def _raw_rows(value: object, mode: PathDisplayMode, key: str = "$", *, is_path: bool = False) -> tuple[tuple[str, str], ...]:
    """Lossless typed scalar leaves with reversible JSON key paths; no row limit.

    Recognized path keys receive only the configured presentation transform.
    The original mapping and sidecars remain untouched.
    """
    if isinstance(value, Mapping) and value:
        return tuple(row for name in sorted(value, key=str) for row in _raw_rows(
            value[name], mode, f"{key}[{json.dumps(str(name), ensure_ascii=False)}]", is_path=_path_key(str(name))))
    if isinstance(value, (list, tuple)) and value:
        return tuple(row for index, child in enumerate(value) for row in _raw_rows(child, mode, f"{key}[{index}]", is_path=is_path))
    if is_path and isinstance(value, str):
        value = _display_path(value, mode)
    if value is None:
        display = "null (값 없음)"
    else:
        display = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return ((key, display),)


def _capture_projection(capture: CapturePoint, mode: PathDisplayMode) -> CapturePresentation:
    return CapturePresentation(capture.label, (
        f"{capture.label}\n상태: {capture.status.value}",
        f"비율: {capture.requested_ratio:.3f}\n프레임: {_integer(capture.requested_frame_index)}\n초: {_seconds_display(capture.requested_seconds)}",
        f"프레임: {_integer(capture.actual_frame_index)}\n초: {_seconds_display(capture.actual_seconds)}",
        f"{_value(capture.actual_timecode)}\n출처: {_value(capture.actual_timecode_source)}",
        f"중복 대상: {_value(capture.duplicate_of)}\n스틸: {_display_path(capture.image_path_exported, mode) if capture.image_path_exported else '-'}",
    ))


def _project_report(output_path: Path, settings: AppSettings, items: tuple[ReportItem, ...]) -> ReportPresentation:
    mode = settings.report.path_display
    clips = []
    for number, item in enumerate(items, 1):
        clip = item.clip
        identity = (
            ("클립 ID", clip.clip_id), ("클립 이름", clip.clip_name),
            ("논리 클립 이름", _value(clip.logical_clip_name)),
            ("소스 경로", _display_path(clip.source_path, mode)),
            *((f"분할 파일 {index}", _display_path(path, mode)) for index, path in enumerate(clip.part_files, 1)),
            *(([("분할 파일", "-")] if not clip.part_files else [])),
            ("형식 / 어댑터", f"{clip.format_family.value} / {item.adapter_name}"),
        )
        media = (
            ("컨테이너", _value(clip.container)), ("코덱", _value(clip.codec)),
            ("파일 크기", f"{_integer(clip.file_size_bytes)} bytes" if clip.file_size_bytes is not None else "-"),
            ("재생 시간", _seconds_display(clip.duration_seconds)),
            ("프레임 수", _integer(clip.frame_count)), ("프레임 레이트", _fps_display(clip)),
            ("너비", _integer(clip.width)), ("높이", _integer(clip.height)),
            ("카메라 제조사", _value(clip.camera_make)), ("카메라 모델", _value(clip.camera_model)),
            ("릴", _value(clip.reel)), ("카메라 ID", _value(clip.camera_id)),
            ("클립 시작 TC", _value(clip.start_timecode)), ("클립 종료 TC", _value(clip.end_timecode)),
            ("클립 TC 출처", _value(clip.timecode_source)), ("드롭 프레임", _value(clip.tc_drop_frame)),
        )
        clips.append(ClipPresentation(number, item, identity, media,
                                     tuple(_capture_projection(c, mode) for c in item.captures), _raw_rows(clip.metadata_raw, mode)))
    counts = Counter(c.status.value for item in items for c in item.captures)
    return ReportPresentation(
        settings.report.project_name or output_path.stem, tuple(clips),
        sum(bool(item.warnings or any(c.warnings for c in item.captures)) for item in items),
        sum(bool(item.errors or any(c.errors for c in item.captures)) for item in items),
        tuple((status.value, counts[status.value]) for status in CaptureStatus),
    )


def _register_fonts() -> None:
    for name, filename in ((FONT_REGULAR, "DataHandlerSans-Regular.ttf"), (FONT_BOLD, "DataHandlerSans-Bold.ttf")):
        if name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name, str(FONT_DIRECTORY / filename)))
    pdfmetrics.registerFontFamily(FONT_REGULAR, normal=FONT_REGULAR, bold=FONT_BOLD, italic=FONT_REGULAR, boldItalic=FONT_BOLD)


def _styles() -> dict[str, ParagraphStyle]:
    base = ParagraphStyle("body", fontName=FONT_REGULAR, fontSize=9, leading=13.5,
                          textColor=INK, spaceAfter=4, splitLongWords=0, allowWidows=0, allowOrphans=0)
    return {
        "body": base,
        "value": ParagraphStyle("value", parent=base, splitLongWords=1),
        "small": ParagraphStyle("small", parent=base, fontSize=8, leading=11.5, textColor=MUTED),
        "label": ParagraphStyle("label", parent=base, fontSize=8, leading=11.5, textColor=MUTED, fontName=FONT_BOLD),
        "title": ParagraphStyle("title", parent=base, fontSize=29, leading=37, fontName=FONT_BOLD, spaceAfter=13),
        "clip": ParagraphStyle("clip", parent=base, fontSize=17, leading=24, fontName=FONT_BOLD, spaceAfter=8, keepWithNext=1),
        "section": ParagraphStyle("section", parent=base, fontSize=14, leading=20, fontName=FONT_BOLD,
                                  textColor=TEAL, spaceBefore=14, spaceAfter=7, keepWithNext=1),
    }


def _p(text: object, style: ParagraphStyle, width: float | None = None) -> Paragraph:
    value = str(text)
    # Normal Korean prose wraps at word boundaries. Only an oversized token
    # (e.g. URL, identifier, or an exceptional unspaced source value) may split.
    if width and not style.splitLongWords and any(pdfmetrics.stringWidth(token, style.fontName, style.fontSize) > width for token in value.split()):
        style = ParagraphStyle(style.name + "-oversized-token", parent=style, splitLongWords=1)
    return Paragraph(escape(value).replace("\n", "<br/>"), style)


def _ruled_table(rows: list[list[object]], widths: list[float], *, repeat: int = 0) -> LongTable:
    result = LongTable(rows, colWidths=widths, repeatRows=repeat, hAlign="LEFT", splitByRow=1, splitInRow=1)
    result.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE),
    ]))
    return result


def _pairs(rows: tuple[tuple[str, str], ...], width: float, styles: dict[str, ParagraphStyle], *, compact: bool = False) -> LongTable:
    if compact:
        widths = [width * .15, width * .35, width * .15, width * .35]
        data = []
        for index in range(0, len(rows), 2):
            pair = rows[index:index + 2]
            values = [entry for key, value in pair for entry in (key, value)]
            if len(values) == 2:
                values.extend(("", ""))
            data.append([_p(value, styles["label" if n % 2 == 0 else "value"], widths[n] - 9) for n, value in enumerate(values)])
    else:
        widths = [98, width - 98]
        data = [[_p(key, styles["label"], 89), _p(value, styles["value"], width - 107)] for key, value in rows]
    return _ruled_table(data, widths)


class _ReportDocument(BaseDocTemplate):  # type: ignore[misc]
    def __init__(self, filename: str, title: str, page_size: tuple[float, float], styles: dict[str, ParagraphStyle]):
        super().__init__(filename, pagesize=page_size, leftMargin=MARGIN, rightMargin=MARGIN,
                         topMargin=52, bottomMargin=45, title=title,
                         author="Data Handler", creator="DataHelper", subject="Sampled frame review / 샘플 프레임 검토")
        self.project_title = title
        self.section_name = "보고서 개요"
        self.page_sections: list[str] = []
        self.styles = styles
        frame = Frame(MARGIN, 45, page_size[0] - 2 * MARGIN, page_size[1] - 97,
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        self.addPageTemplates(PageTemplate(id="report", frames=[frame], onPageEnd=self._furniture))

    def beforePage(self) -> None:
        self.page_sections = []

    def _furniture(self, pdf: Canvas, doc: BaseDocTemplate) -> None:
        width, height = self.pagesize
        pdf.saveState()
        pdf.setStrokeColor(RULE)
        pdf.setLineWidth(.5)
        pdf.line(MARGIN, height - 35, width - MARGIN, height - 35)
        # A long full title is in the story and document metadata. The running
        # header uses it only when it fits, avoiding truncation or path leaks.
        section = self.section_name
        if self.page_sections:
            first, last = self.page_sections[0], self.page_sections[-1]
            section = first if first == last else f"{first} / {last}"
        heading = self.project_title
        section_width = pdfmetrics.stringWidth(section, FONT_REGULAR, 8)
        if pdfmetrics.stringWidth(heading, FONT_REGULAR, 8) > width - 2 * MARGIN - max(100, section_width + 20):
            heading = "Data Handler / 샘플 프레임 검토"
        pdf.setFont(FONT_REGULAR, 8)
        pdf.setFillColor(MUTED)
        pdf.drawString(MARGIN, height - 26, heading)
        pdf.drawRightString(width - MARGIN, height - 26, section)
        pdf.line(MARGIN, 33, width - MARGIN, 33)
        pdf.drawString(MARGIN, 20, "DataHelper · 샘플 캡처 및 메타데이터 기록")
        pdf.drawRightString(width - MARGIN, 20, f"Page {doc.page}")
        pdf.restoreState()

    def afterFlowable(self, flowable: object) -> None:
        section = getattr(flowable, "report_section", None)
        if section:
            self.section_name = section
        # Breaks, spacers and decorative rules do not establish page context.
        # Real continuation content inherits the last section, while a section
        # opening before any content replaces the preceding page's context.
        if isinstance(flowable, (Paragraph, Table, PDFImage)):
            if not self.page_sections or self.page_sections[-1] != self.section_name:
                self.page_sections.append(self.section_name)


def _section(text: str, styles: dict[str, ParagraphStyle], *, running: str | None = None) -> Paragraph:
    paragraph = _p(text, styles["section"])
    if running:
        paragraph.report_section = running
    return paragraph


def _intro(presentation: ReportPresentation, settings: AppSettings, summary: BatchSummary,
           layout: ReportLayout, width: float, styles: dict[str, ParagraphStyle]) -> list[object]:
    story: list[object] = [
        _p("DATA HANDLER / FRAME REVIEW", styles["label"]),
        _p(presentation.title, styles["title"] if settings.report.include_summary_page and presentation.clips else styles["clip"], width),
        _p("샘플 프레임과 미디어 메타데이터를 확인하는 인계 보고서입니다.", styles["body"], width),
        _p(f"생성 시각: {datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S %z')}  |  레이아웃: {layout.value}", styles["small"], width),
    ]
    metric_style = ParagraphStyle("metric", parent=styles["title"], fontSize=27, leading=32, textColor=TEAL, spaceAfter=0)
    metric_values = (len(presentation.clips), summary.success_count, presentation.warning_clips)
    metric_labels = ("수록 클립", "정상 처리", "경고가 있는 클립")
    metrics = Table([
        [_p(_integer(value), metric_style) for value in metric_values],
        [_p(label, styles["label"], width / 3 - 10) for label in metric_labels],
    ], colWidths=[width / 3] * 3, hAlign="LEFT")
    metrics.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0),
                                ("TOPPADDING", (0, 0), (-1, 0), 10),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                                ("LINEBELOW", (0, -1), (-1, -1), 1, TEAL)]))
    story.extend((metrics, _section("처리 결과", styles)))
    counts = (
        ("배치 상태", summary.status.value), ("전체 클립", _integer(summary.total_clips)),
        ("부분 성공", _integer(summary.partial_success_count)), ("건너뜀", _integer(summary.skipped_count)),
        ("메타데이터 조회 실패", _integer(summary.probe_failed_count)), ("디코딩 실패", _integer(summary.decode_failed_count)),
    )
    story.append(_pairs(counts, width, styles, compact=True))
    story.append(_p(f"경고가 있는 클립: {presentation.warning_clips}  /  오류가 있는 클립: {presentation.error_clips}  /  캡처 지점: {sum(n for _, n in presentation.capture_counts)}", styles["body"], width))
    story.append(_p("캡처 상태: " + " / ".join(f"{status} {count}" for status, count in presentation.capture_counts), styles["small"], width))
    if summary.total_clips != len(presentation.clips):
        story.append(_p("제공된 배치 집계와 이 문서의 수록 범위가 다릅니다. 집계값은 전달받은 값 그대로 표시합니다.", styles["body"], width))
    story.append(_section("입력 범위와 캡처 설정", styles))
    rows = tuple((f"입력 {index}", _display_path(str(path), settings.report.path_display)) for index, path in enumerate(settings.input.paths, 1))
    rows += (
        ("캡처 프로필", settings.capture.profile),
        ("중간 캡처 / 위치 우선", f"{settings.capture.middle_count}개 / {'프레임 인덱스' if settings.capture.prefer_frame_index else '시간 (초)'}"),
        ("하위 폴더 / 확장자", f"{_value(settings.input.recursive)} / {', '.join(settings.input.extensions)}"),
        ("경로 표시", settings.report.path_display.value),
    )
    story.append(_pairs(rows, width, styles, compact=layout is ReportLayout.CLIP_DETAIL))
    story.append(Spacer(1, 10))
    story.append(_p("읽는 법: -는 값이 없음을 뜻하며 0과 false는 실제 값입니다. 초와 비율은 소수 셋째 자리로 반올림합니다. 클립 TC는 저장된 메타데이터이고, 캡처 TC는 실제 추출 지점의 기록입니다.", styles["small"], width))
    story.append(_p("확인 범위: 지정한 지점의 프레임 추출과 메타데이터를 기록합니다. 전체 프레임 디코딩, 체크섬 일치, 원본·복제본 메타데이터 일치, 색 정확도를 검증한 결과는 아닙니다. 경고·오류 집계는 메시지가 있는 클립 수이며 중복 메시지를 별도 사건으로 세지 않습니다.", styles["small"], width))
    if not presentation.clips:
        story.append(_section("보고서에 포함할 클립이 없습니다.", styles))
    elif settings.report.include_summary_page:
        story.append(PageBreak())
    return story


def _display_image_path(capture: CapturePoint | None) -> Path | None:
    if capture is None:
        return None
    for value in (capture.image_path_exported, capture.image_path_temp):
        if value:
            return Path(value)
    return None


def _fit_dimensions(size: tuple[int, int], max_width: float, max_height: float) -> tuple[float, float]:
    scale = min(max_width / size[0], max_height / size[1])
    return size[0] * scale, size[1] * scale


def _fit_image(path: Path, max_width: float, max_height: float) -> tuple[float, float]:
    try:
        with Image.open(path) as image:
            oriented = ImageOps.exif_transpose(image)
            return _fit_dimensions(oriented.size, max_width, max_height)
    except (OSError, ValueError):
        return max_width, max_height


def _preview(capture: CapturePoint | None, width: float, height: float,
             styles: dict[str, ParagraphStyle]) -> tuple[object, str | None]:
    path = _display_image_path(capture)
    reason = "캡처 미설정" if capture is None else "파일 없음"
    if path is not None:
        try:
            with Image.open(path) as image:
                oriented = ImageOps.exif_transpose(image)
                dimensions = _fit_dimensions(oriented.size, width, height)
                target = max(96, min(PDF_IMAGE_MAX_PIXELS, int(max(width, height) * 2)))
                oriented.thumbnail((target, target), Image.Resampling.LANCZOS)
                prepared = oriented if oriented.mode in {"RGB", "L"} else oriented.convert("RGB")
                buffer = BytesIO()
                prepared.save(buffer, format="JPEG", quality=PDF_IMAGE_QUALITY, optimize=True)
                buffer.seek(0)
            return PDFImage(buffer, width=dimensions[0], height=dimensions[1], hAlign="LEFT"), None
        except FileNotFoundError:
            reason = "파일 없음"
        except (OSError, ValueError):
            reason = "이미지 읽기 실패"
    if reason == "파일 없음" and capture is not None and capture.status is not CaptureStatus.SUCCESS:
        reason = capture.status.value
    placeholder = Table([[_p("미리보기 없음\n" + reason, styles["small"], width - 16)]],
                        colWidths=[width], rowHeights=[min(height, 88)], hAlign="LEFT")
    placeholder.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                    ("LINEABOVE", (0, 0), (-1, -1), .5, RULE),
                                    ("LINEBELOW", (0, 0), (-1, -1), .5, RULE)]))
    return placeholder, reason


def _start_middle_end_captures(captures: tuple[CapturePoint, ...]) -> tuple[CapturePoint | None, CapturePoint | None, CapturePoint | None]:
    start = next((c for c in captures if c.label == "Start"), None)
    end = next((c for c in captures if c.label == "End"), None)
    middle = [c for c in captures if c.label.startswith("Mid")]
    return start, min(middle, key=lambda c: abs(c.requested_ratio - .5)) if middle else None, end


def _gallery(item: ReportItem, layout: ReportLayout, width: float, styles: dict[str, ParagraphStyle]) -> list[object]:
    if layout is ReportLayout.CONTACT_SHEET:
        start, middle, end = _start_middle_end_captures(item.captures)
        middle_count = sum(c.label.startswith("Mid") for c in item.captures)
        middle_label = f"중간 ({middle.label}, {middle_count}개 중 대표)" if middle else "중간 캡처 미설정"
        selected = [(start, "시작 (Start)"), (middle, middle_label), (end, "끝 (End)")]
        columns, max_height = 3, 145.0
    else:
        selected = [(c, f"캡처 {c.label}") for c in item.captures]
        columns, max_height = 2, 165.0
    if not selected:
        return [_p("캡처 지점이 없습니다. 클립 정보와 메시지를 확인하세요.", styles["body"], width)]
    gap = 12
    cell_width = (width - gap * (columns - 1)) / columns
    result: list[object] = []
    for offset in range(0, len(selected), columns):
        row = selected[offset:offset + columns]
        captions, previews, statuses = [], [], []
        for capture, label in row:
            preview, reason = _preview(capture, cell_width, max_height, styles)
            captions.append(_p(label, styles["label"], cell_width))
            previews.append(preview)
            timing = (
                f"추출 상태: {capture.status.value}\n실제 TC: {_value(capture.actual_timecode)}\n"
                f"프레임: {_integer(capture.actual_frame_index)} / 초: {_seconds_display(capture.actual_seconds)}"
                if capture else "추출 상태: -\n실제 TC: -\n프레임: - / 초: -"
            )
            statuses.append(_p(timing, styles["small"], cell_width))
        while len(captions) < columns:
            captions.append("")
            previews.append("")
            statuses.append("")
        def spaced(values: list[object]) -> list[object]:
            return [entry for index, value in enumerate(values) for entry in ((["", value] if index else [value]))]
        table = Table([spaced(captions), spaced(previews), spaced(statuses)],
                      colWidths=[n for index in range(columns) for n in (([gap, cell_width] if index else [cell_width]))],
                      hAlign="LEFT", splitByRow=0, splitInRow=0)
        table.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                  ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                                  ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        result.extend((table, Spacer(1, 7)))
    return result


def _capture_table(clip: ClipPresentation, width: float, styles: dict[str, ParagraphStyle]) -> object:
    if not clip.captures:
        return _p("캡처 지점: 0 (클립 식별 정보는 위에 수록)", styles["body"], width)
    widths = [width * n for n in (.16, .19, .18, .22, .25)]
    headings = ("캡처 / 상태", "요청 위치", "실제 위치", "실제 TC / 출처", "중복 / 내보낸 스틸")
    rows = [[_p(text, styles["label"], w - 9) for text, w in zip(headings, widths)]]
    rows.extend([_p(text, styles["value"], w - 9) for text, w in zip(capture.cells, widths)] for capture in clip.captures)
    return _ruled_table(rows, widths, repeat=1)


def _messages(item: ReportItem, mode: PathDisplayMode, width: float, styles: dict[str, ParagraphStyle]) -> list[object]:
    story: list[object] = []
    groups = [("Report messages", item.warnings, item.errors)]
    groups.extend((f"Capture {c.label}", c.warnings, c.errors) for c in item.captures)
    for scope, warnings, errors in groups:
        if not warnings and not errors:
            continue
        scope_label = _p(scope, styles["label"], width)
        scope_label.keepWithNext = True
        story.append(scope_label)
        for index, warning in enumerate(warnings, 1):
            story.append(_p(f"경고 {index}: {warning}", styles["body"], width))
        for index, error in enumerate(errors, 1):
            story.append(_p(f"오류 {index} / {error.code.value}: {error.message}", styles["body"], width))
            for key, value in _raw_rows(error.detail, mode):
                detail_label = _p(f"detail {key}", styles["label"], width)
                detail_label.keepWithNext = True
                story.append(detail_label)
                story.append(_p(value, styles["value"], width))
    return story or [_p("기록된 경고와 오류가 없습니다.", styles["body"], width)]


def _clip_story(clip: ClipPresentation, layout: ReportLayout, settings: AppSettings,
                width: float, styles: dict[str, ParagraphStyle]) -> list[object]:
    item = clip.item
    heading = _p(f"{clip.number:03d} / {item.clip.clip_name}", styles["clip"], width)
    heading.report_section = f"클립 {clip.number:03d}"
    status = _p(f"클립 상태: {item.status.value}", styles["body"], width)
    status.keepWithNext = True
    compact_media = _p(f"{item.clip.format_family.value} / {_value(item.clip.codec)} / {_value(item.clip.width)} × {_value(item.clip.height)} / {_fps_display(item.clip)} / {_seconds_display(item.clip.duration_seconds)}", styles["small"], width)
    compact_media.keepWithNext = True
    story: list[object] = [CondPageBreak(130), Spacer(1, 12), HRFlowable(width="100%", thickness=1, color=TEAL),
                          Spacer(1, 10), heading, status, compact_media,
                          _section("프레임 미리보기", styles)]
    story.extend(_gallery(item, layout, width, styles))
    story.extend((_section("클립 식별 정보", styles), _pairs(clip.identity, width, styles),
                  _section("미디어 메타데이터", styles), _pairs(clip.media, width, styles, compact=True)))
    story.extend((_section("캡처 근거", styles), _capture_table(clip, width, styles), _section("메시지", styles)))
    story.extend(_messages(item, settings.report.path_display, width, styles))
    story.append(_p(f"원시 메타데이터 전체: 부록의 클립 {clip.number:03d} 참조", styles["small"], width))
    return story


def _render(output_path: Path, settings: AppSettings, items: Iterable[ReportItem], summary: BatchSummary, layout: ReportLayout) -> None:
    item_list = tuple(items)
    presentation = _project_report(output_path, settings, item_list)
    _register_fonts()
    styles = _styles()
    page_size = DETAIL_PAGE_SIZE if layout is ReportLayout.CLIP_DETAIL else CONTACT_SHEET_PAGE_SIZE
    width = page_size[0] - 2 * MARGIN
    output_path.parent.mkdir(parents=True, exist_ok=True)
    document = _ReportDocument(str(output_path), presentation.title, page_size, styles)
    story = _intro(presentation, settings, summary, layout, width, styles)
    for clip in presentation.clips:
        story.extend(_clip_story(clip, layout, settings, width, styles))
    issues = [clip for clip in presentation.clips if clip.item.status is not ClipStatus.SUCCESS]
    if settings.report.include_failed_section and issues:
        story.extend((PageBreak(), _section("확인이 필요한 클립 / 이슈 색인", styles, running="이슈 색인"),
                      _p("성공 이외 상태의 클립입니다. 전체 경고·오류와 캡처 근거는 각 번호의 클립 본문에 수록했습니다.", styles["body"], width)))
        for clip in issues:
            label = _p(f"클립 {clip.number:03d} / {clip.item.status.value}", styles["label"], width)
            label.keepWithNext = True
            story.extend((label, _p(f"{clip.item.clip.clip_id}\n{clip.item.clip.clip_name}", styles["value"], width),
                          HRFlowable(width="100%", thickness=.4, color=RULE), Spacer(1, 10)))
    if presentation.clips:
        story.extend((PageBreak(), _section("부록 / 원시 메타데이터", styles, running="원시 메타데이터"),
                      _p("저장된 metadata_raw 전체입니다. 정렬된 JSON 키 경로와 원래 값의 표현을 보존합니다. 문자열은 따옴표, null은 값 없음으로 표시합니다. 경로로 식별되는 키에는 경로 표시 설정을 적용했습니다.", styles["small"], width)))
        widths = [width * .34, width * .66]
        for clip in presentation.clips:
            story.extend((CondPageBreak(100), _section(f"클립 {clip.number:03d} / {clip.item.clip.clip_id}", styles, running=f"부록 · 클립 {clip.number:03d}")))
            rows = [[_p("키 (JSON 경로)", styles["label"]), _p("저장된 값", styles["label"])]]
            rows.extend([_p(key, styles["small"], widths[0] - 9), _p(value, styles["value"], widths[1] - 9)] for key, value in clip.raw)
            story.append(_ruled_table(rows, widths, repeat=1))
    document.build(story)


def render_pdf(output_path: Path, settings: AppSettings, items: Iterable[ReportItem], summary: BatchSummary) -> None:
    if settings.report.layout is ReportLayout.CLIP_DETAIL:
        render_detail_pdf(output_path, settings, items, summary)
    else:
        render_contact_sheet_pdf(output_path, settings, items, summary)


def render_contact_sheet_pdf(output_path: Path, settings: AppSettings, items: Iterable[ReportItem], summary: BatchSummary) -> None:
    _render(output_path, settings, items, summary, ReportLayout.CONTACT_SHEET)


def render_detail_pdf(output_path: Path, settings: AppSettings, items: Iterable[ReportItem], summary: BatchSummary) -> None:
    _render(output_path, settings, items, summary, ReportLayout.CLIP_DETAIL)
